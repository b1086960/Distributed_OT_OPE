package helpers;

public class Setting {

	public static int fieldSize =64;        	// Size of entries in vectors 
	public static int P_size    =256;			// Size of prime number Z_p
	public static boolean testing_mode=false;	// "testing" mode or "multi-threading" mode

}
